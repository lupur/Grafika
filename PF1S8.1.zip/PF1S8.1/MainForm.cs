﻿// -----------------------------------------------------------------------
// <file>MainForm.cs</file>
// <copyright>Grupa za Grafiku, Interakciju i Multimediju 2013.</copyright>
// <author>Zoran Milicevic</author>
// <summary>Demonstracija ucitavanja modela pomocu AssimpNet biblioteke i koriscenja u OpenGL-u.</summary>
// -----------------------------------------------------------------------
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Assimp;
using System.IO;
using System.Reflection;

namespace RacunarskaGrafika.Vezbe.AssimpNetSample
{
    public partial class MainForm : Form
    {
        #region Atributi

        /// <summary>
        ///	 Instanca OpenGL "sveta" - klase koja je zaduzena za iscrtavanje koriscenjem OpenGL-a.
        /// </summary>
        World m_world = null;
        decimal brojacPrvi = 0;
        decimal brojacDrugi = 0;
        decimal brojacTreci = 0;
        public static float brzinaOtvaranja = 1.0f;
        long duzina = 250;

        long duzinaOtvaranjaVrata = 100;
        long duzinaZatvaranjaVrata = 100;

        public static bool blokiraj = false;
        public static bool blokirajVrata = false;
        
        #endregion Atributi

        #region Konstruktori

        public MainForm()
        {
            // Inicijalizacija komponenti
            InitializeComponent();

            // Inicijalizacija OpenGL konteksta
            openglControl.InitializeContexts();

            // Kreiranje OpenGL sveta
            try
            {
                m_world = new World(Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "3D Models\\balon3"), "baloons.obj", openglControl.Width, openglControl.Height);
            }
            catch (Exception e)
            {
                MessageBox.Show("Neuspesno kreirana instanca OpenGL sveta. Poruka greške: " + e.Message, "GRESKA", MessageBoxButtons.OK, MessageBoxIcon.Error);
                this.Close();
            }
        }

        #endregion Konstruktori

        #region Rukovaoci dogadjajima OpenGL kontrole

        /// <summary>
        /// Rukovalac dogadja izmene dimenzija OpenGL kontrole
        /// </summary>
        private void OpenGlControlResize(object sender, EventArgs e)
        {
            m_world.Height = openglControl.Height;
            m_world.Width = openglControl.Width;

            m_world.Resize();
        }

        /// <summary>
        /// Rukovalac dogadjaja iscrtavanja OpenGL kontrole
        /// </summary>
        private void OpenGlControlPaint(object sender, PaintEventArgs e)
        {
            // Iscrtaj svet
            m_world.Draw(); 
        }

        /// <summary>
        /// Rukovalac dogadjaja: obrada tastera nad formom
        /// </summary>
        private void OpenGlControlKeyDown(object sender, KeyEventArgs e)
        {
           
                switch (e.KeyCode)
                {
                    case Keys.K:
                        if (!blokiraj && !blokirajVrata && m_world.Pomeraj > -100.0f)
                        {
                            blokiraj = true;
                            tajmerAnimacija.Stop();
                            zatvaranjeVrata.Stop();
                            blokirajVrata = true;
                            otvaranjeVrata.Start();
                            duzinaOtvaranjaVrata = 100;
                            m_world.Pomeraj = 0;

                        }
                        break;
                    case Keys.L:
                        if (!blokiraj && !blokirajVrata && m_world.Pomeraj < 0)
                        {
                            blokiraj = true;

                            otvaranjeVrata.Stop();
                            tajmerAnimacija.Stop();
                            blokirajVrata = true;
                            zatvaranjeVrata.Start();
                            duzinaZatvaranjaVrata = 100;
                            m_world.Pomeraj = -100;


                        }
                        break;
                    case Keys.T:
                        if (!(m_world.RotationX < 5.0f) && !blokiraj)
                            m_world.RotationX -= 5.0f; break;
                    case Keys.G:
                        if (m_world.RotationX < 100.0f && !blokiraj)
                            m_world.RotationX += 5.0f; break;
                    case Keys.F:
                        if (!blokiraj)
                        {
                            m_world.RotationY -= 5.0f;
                        }
                        break;
                    case Keys.H:
                        if(!blokiraj)
                          m_world.RotationY += 5.0f;
                        break;
                    case Keys.Add:
                        if (m_world.SceneDistance > 7080 && !blokiraj)
                            m_world.SceneDistance -= 5.0f; break;
                    case Keys.Subtract:
                        if (m_world.SceneDistance < 7285 && !blokiraj)
                            m_world.SceneDistance += 5.0f; break;
                    case Keys.F2:
                        this.Dispose(); break;

                    case Keys.X:
                        {
                            if (!blokiraj)
                            {
                                otvaranjeVrata.Stop();
                                zatvaranjeVrata.Stop();
                                blokiraj = true;
                                m_world.Pomeraj = 0;
                                tajmerAnimacija.Start();
                                duzina = 250;
                                break;
                            }

                            break;
                        }

                  /*  case Keys.W:
                        {
                            if (!blokiraj)
                                World.zPomerajBalona -= 5;
                            Console.Out.WriteLine("x:" + World.xPomerajBalona + ", y:" + World.yPomerajBalona + " z:" + World.zPomerajBalona);

                            break;
                        }

                    case Keys.S:
                        {
                            if (!blokiraj)
                                World.zPomerajBalona += 5;
                            Console.Out.WriteLine("x:" + World.xPomerajBalona + ", y:" + World.yPomerajBalona + " z:" + World.zPomerajBalona);

                            break;
                        }
                    case Keys.A:
                        {
                            if (!blokiraj)
                                World.xPomerajBalona -= 5;
                            Console.Out.WriteLine("x:" + World.xPomerajBalona + ", y:" + World.yPomerajBalona + " z:" + World.zPomerajBalona);

                            break;
                        }
                    case Keys.D:
                        {
                            if (!blokiraj)
                                World.xPomerajBalona += 5;
                            Console.Out.WriteLine("x:" + World.xPomerajBalona + ", y:" + World.yPomerajBalona + " z:" + World.zPomerajBalona);

                            break;
                        }
                    case Keys.Q:
                        {
                            if (!blokiraj)
                                World.yPomerajBalona += 5;
                            Console.Out.WriteLine("x:" + World.xPomerajBalona + ", y:" + World.yPomerajBalona + " z:" + World.zPomerajBalona);

                            break;
                        }
                    case Keys.Z:
                        {
                            if (!blokiraj)
                                World.yPomerajBalona -= 5;
                            Console.Out.WriteLine("x:" + World.xPomerajBalona + ", y:" + World.yPomerajBalona + " z:" + World.zPomerajBalona);

                            break;
                        }*/

                }
           
            openglControl.Refresh();
        }

        #endregion Rukovaoci dogadjajima OpenGL kontrole

        private void MainForm_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 28; i++)
            {
                m_world.Draw();
            }
        }

        private void openglControl_Load(object sender, EventArgs e)
        {

        }

        private void izborVisineHangara_SelectedItemChanged(object sender, EventArgs e)
        {
        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {
            World.promenaVisineHangara();

            if (numericUpDown1.Value > brojacPrvi)
            {
                World.visinaHangara += 5;
                World.polozajAnteneDisk += 5;
                World.polozajAnteneOsnova += 5f;
                World.polozajAnteneValjakY += 5f;
                World.pozicijaHangara += 2.5f;
                m_world.kreiranjeHangara();
                m_world.Draw();
                System.Console.WriteLine(World.visinaHangara);
                brojacPrvi = numericUpDown1.Value;
            }

            else
            {
                World.visinaHangara -= 5;
                World.polozajAnteneDisk -= 5f;
                World.polozajAnteneOsnova -= 5f;
                World.polozajAnteneValjakY -= 5f;
                World.pozicijaHangara -= 2.5f;

                m_world.Draw();
                System.Console.WriteLine(World.visinaHangara);
                brojacPrvi = numericUpDown1.Value;
            }
            openglControl.Refresh();
        }

        private void numericUpDown1_KeyUp(object sender, KeyEventArgs e)
        {

        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown2.Value > brojacDrugi)
            {
                World.duzinaAntene += 0.2f;

                World.polozajAnteneValjakY += 0.17f;
                World.polozajAnteneValjakZ += 0.11f;
                m_world.Draw();

                brojacDrugi = numericUpDown2.Value;




            }

            else
            {
                World.duzinaAntene -= 0.2f;

                World.polozajAnteneValjakY -= 0.17f;
                World.polozajAnteneValjakZ -= 0.11f;

                m_world.Draw();

                brojacDrugi = numericUpDown2.Value;

            }
            openglControl.Refresh();

        }

        private void numericUpDown3_ValueChanged(object sender, EventArgs e)
        {
            if (numericUpDown3.Value > brojacTreci)
            {
                brzinaOtvaranja += 1;
                brojacTreci = numericUpDown3.Value;
            }

            else
            {
                brzinaOtvaranja -= 1; 
                brojacTreci = numericUpDown3.Value;

            }
        }

        private void tajmerAnimacija_Tick(object sender, EventArgs e)
        {
                
                m_world.animacija(--duzina);
                openglControl.Refresh();
          
            
                
        }

        private void otvaranjeVrata_Tick(object sender, EventArgs e)
        {
            m_world.otvaranjeVrata(--duzinaOtvaranjaVrata);
            openglControl.Refresh();

        }

        private void zatvaranjeVrata_Tick(object sender, EventArgs e)
        {
            m_world.zatvaranjeVrata(--duzinaZatvaranjaVrata);
            openglControl.Refresh();
        }

       
    }
}
